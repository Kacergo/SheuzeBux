-- Auto Ativar Buso Haki
print("Buso Haki ativado")
-- Código do busoken