-- Auto Haki de Observação
print("Haki de Observação ativado")
-- Código do haki