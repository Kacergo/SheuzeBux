-- Fly Script
print("Modo voo ativado")
-- Código fly aqui