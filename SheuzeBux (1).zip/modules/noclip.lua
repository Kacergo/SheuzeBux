-- Noclip ativado
print("Noclip ativado")
-- Código noclip aqui