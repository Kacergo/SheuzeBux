-- Loader principal
local Rayfield = loadstring(game:HttpGet("https://raw.githubusercontent.com/shlexware/Rayfield/main/source.lua"))()
local Window = Rayfield:CreateWindow({
   Name = "Sheuze Bux | Blox Fruit V1",
   LoadingTitle = "Sheuze Bux",
   LoadingSubtitle = "by sheuzes",
   ConfigurationSaving = {
      Enabled = false,
   },
   Discord = {
      Enabled = true,
      Invite = "sheuzebux",
      RememberJoins = true
   },
   KeySystem = false,
})

-- Funções
local Tab = Window:CreateTab("🌀 Farm", {Icon = "rbxassetid://4483345998"})
Tab:CreateButton({
   Name = "Ativar Auto Farm",
   Callback = function()
      loadstring(game:HttpGet("https://raw.githubusercontent.com/seuusuario/SheuzeBux/main/modules/autofarm.lua"))()
   end,
})