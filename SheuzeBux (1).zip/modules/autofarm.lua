-- Auto Farm de Mobs
print("Auto Farm ativado")
-- Código de farm aqui