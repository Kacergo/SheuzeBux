-- ESP de inimigos e baús
print("ESP ativado")
-- Código ESP aqui